//
//  Penguin_ExplorerApp.swift
//  Penguin Explorer
//
//  Created by formando on 10/09/2024.
//

import SwiftUI

@main
struct Penguin_ExplorerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
